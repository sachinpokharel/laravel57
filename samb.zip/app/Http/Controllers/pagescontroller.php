<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class pagescontroller extends Controller
{
    public function login()
    {
        return view('login');
    }
    public function index()
    {
        return view('index');
    }
    public function welcome()
    {
        return view('welcome');
    }
    public function create()
    {
       return view('back.categorys.create');
    }
}
