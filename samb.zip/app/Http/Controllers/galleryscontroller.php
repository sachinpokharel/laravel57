<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\gallerys;

class galleryscontroller extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pics = gallerys::all();
        return view('back.gallerys.index', compact('pics'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('back.gallerys.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required|string|min:5',
            'gtype'=>'required|integer',
            'description'=> 'required|string',
            'image'=>'required|string',
            'status' => 'required|boolean'
        ]);
        $pics = new gallerys([
            'gtype'=> $request->get('gtype'),
            'name' => $request->get('name'),
            'description'=> $request->get('description'),
            'image'=>$request-> get('image'),
            'status'=> $request->get('status')
        ]);
        $pics->save();
        return redirect('/pics')->with('success', 'gallery added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pics = gallerys::find($id);
        return view('back.gallerys.edit', compact('pics'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
            $request->validate([
                'name'=>'required|string|min:5',
                'gtype'=>'required|integer',
                'description'=> 'required|string',
                'image'=>'required|string',
                'status' => 'required|boolean'
            ]);


          $pics = gallery::find($id);
          $pics->name = $request->get('name');
          $pics->description = $request->get('description');
          $pics->image = $request->get('image');
          $pics->status = $request->get('status');
          $pics->save();


          return redirect('/pics')->with('success', 'gallery has been updated');
    }
    // {

    //   $pics = gallery::find($id);

    //   $pics->name = $request->get('name');
    //   $pics->description = $request->get('description');
    //   $pics->status = $request->get('status');

    //   return redirect('/cats')->with('success', 'gallery has been updated');

    // }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pics = gallerys::find($id);
        $pics->delete();

        return redirect('/pics')->with('success', 'gallery has been deleted Successfully');
    }
}
