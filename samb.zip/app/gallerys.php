<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gallerys extends Model
{

    protected $table="gallerys";
  protected $fillable = [
      'gtype',
      'gtype',
      'description',
      'image',
      'status'
    ];
}
