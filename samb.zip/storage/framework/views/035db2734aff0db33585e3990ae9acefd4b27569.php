<?php /* C:\xampp\htdocs\samb\resources\views/back/gallerys/create.blade.php */ ?>
<html lang="en">
<head>
  <title>Laravel Multiple File Upload Example</title>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<body>
  <div class="container">
      <?php if(count($errors) > 0): ?>
      <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <?php endif; ?>

        <?php if(session('success')): ?>
        <div class="alert alert-success">
          <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

    <h3 class="jumbotron">Laravel Multiple pictures Upload</h3>

    <form method="post" action="<?php echo e(route('pics.store')); ?>">
            <div class="form-group">
                <?php echo csrf_field(); ?>
                <label for="name">picture Name:</label>
                <input type="text" class="form-control" name="name"/>
            </div>
            <div class="form-group">
                    <label for="gtype">gtype</label>
                    <input type="number" class="form-control" name="gtype"/>
                </div>
            <div class="form-group">
                <label for="description">picture Description</label>
                <input type="text" class="form-control" name="description"/>
            </div>

            <div class="form-group">
            <label for="image">images</label>
            <input type="file" name="image" class="form-control">
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <input type="text" class="form-control" name="status"/>
            </div>
            <button type="submit" class="btn btn-primary">Add</button>
        </form>

<!-- /**
<form method="post" action="<?php echo e(url('gallerys')); ?>" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>


        <div class="input-group control-group increment" >
            name:
            <input type="text" name= 'name' class='form-control'><br>
            description:
            <input type="text" name= 'description' class='form-control'><br>
          <input type="file" name="filename[]" class="form-control">
          <div class="input-group-btn">
            <button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
          </div>
        </div>
        <div class="clone hide">
          <div class="control-group input-group" style="margin-top:10px">
            <input type="file" name="filename[]" class="form-control">
            <div class="input-group-btn">
              <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
            </div>
          </div>
        </div>

        <button type="submit" class="btn btn-primary" style="margin-top:10px">Submit</button>

  </form>
   -->
  </div>


<script type="text/javascript">


    $(document).ready(function() {

      $(".btn-success").click(function(){
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){
          $(this).parents(".control-group").remove();
      });

    });

</script>
</body>
</html>
